from django.shortcuts import render
from . models import Contact
# Create your views here.



def contact(request):
   
    if request.method=="POST":
        name = request.POST['name']
        email = request.POST['email']
        number = request.POST['number']
        foodName = request.POST['foodName']
        address = request.POST['address']

        obj = Contact(name=name, email=email, number=number, foodName=foodName, address=address)
        obj.save()
    
    return render(request, 'index.html')

def getCustomerInfo(request):
    customer = Contact.objects.all()
    return render(request, 'customer_details.html', {'customer': customer})