from django.urls import path
from .import views
urlpatterns=[
    path('', views.contact, name='contact'),
    path('customer_info/', views.getCustomerInfo, name="customer_info" ),
]